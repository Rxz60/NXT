ALTER TABLE `generated_sites` ADD `slug` varchar(120) NOT NULL;--> statement-breakpoint
ALTER TABLE `generated_sites` ADD `isPublished` boolean DEFAULT false NOT NULL;--> statement-breakpoint
ALTER TABLE `generated_sites` ADD `version` int DEFAULT 1 NOT NULL;--> statement-breakpoint
ALTER TABLE `generated_sites` ADD `publishedAt` timestamp;--> statement-breakpoint
ALTER TABLE `generated_sites` ADD CONSTRAINT `generated_sites_slug_unique` UNIQUE(`slug`);