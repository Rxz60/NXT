CREATE TABLE `bot_projects` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`platform` enum('telegram','discord') NOT NULL,
	`name` varchar(160) NOT NULL,
	`prompt` text NOT NULL,
	`encryptedToken` text NOT NULL,
	`tokenHint` varchar(40) NOT NULL,
	`status` enum('draft','ready','running','stopped') NOT NULL DEFAULT 'draft',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bot_projects_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `generated_sites` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`prompt` text NOT NULL,
	`html` text NOT NULL,
	`shareToken` varchar(80) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `generated_sites_id` PRIMARY KEY(`id`),
	CONSTRAINT `generated_sites_shareToken_unique` UNIQUE(`shareToken`)
);
