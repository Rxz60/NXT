CREATE TABLE `lua_file_versions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`luaFileId` int NOT NULL,
	`userId` int NOT NULL,
	`version` int NOT NULL,
	`code` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `lua_file_versions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `lua_files` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(160) NOT NULL,
	`filename` varchar(255) NOT NULL,
	`code` text NOT NULL,
	`storageKey` text NOT NULL,
	`rawToken` varchar(96) NOT NULL,
	`version` int NOT NULL DEFAULT 1,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `lua_files_id` PRIMARY KEY(`id`),
	CONSTRAINT `lua_files_rawToken_unique` UNIQUE(`rawToken`)
);
