ALTER TABLE `bot_projects` ADD `attachments` text;--> statement-breakpoint
ALTER TABLE `bot_projects` ADD `generatedConfig` text;