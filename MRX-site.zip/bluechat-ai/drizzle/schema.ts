import { boolean, int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const conversations = mysqlTable("conversations", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).default("محادثة جديدة").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const chatMessages = mysqlTable("chat_messages", {
  id: int("id").autoincrement().primaryKey(),
  conversationId: int("conversationId").notNull(),
  userId: int("userId").notNull(),
  role: mysqlEnum("role", ["user", "assistant"]).notNull(),
  content: text("content").notNull(),
  attachments: text("attachments"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const uploadedFiles = mysqlTable("uploaded_files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  originalName: varchar("originalName", { length: 255 }).notNull(),
  storageKey: text("storageKey").notNull(),
  url: text("url").notNull(),
  mimeType: varchar("mimeType", { length: 160 }).notNull(),
  size: int("size").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export const generatedSites = mysqlTable("generated_sites", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  prompt: text("prompt").notNull(),
  html: text("html").notNull(),
  shareToken: varchar("shareToken", { length: 80 }).notNull().unique(),
  isPublished: boolean("isPublished").default(false).notNull(),
  version: int("version").default(1).notNull(),
  publishedAt: timestamp("publishedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const botProjects = mysqlTable("bot_projects", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  platform: mysqlEnum("platform", ["telegram", "discord"]).notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  prompt: text("prompt").notNull(),
  encryptedToken: text("encryptedToken").notNull(),
  tokenHint: varchar("tokenHint", { length: 40 }).notNull(),
  attachments: text("attachments"),
  generatedConfig: text("generatedConfig"),
  status: mysqlEnum("status", ["draft", "ready", "running", "stopped"]).default("draft").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const luaFiles = mysqlTable("lua_files", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  filename: varchar("filename", { length: 255 }).notNull(),
  code: text("code").notNull(),
  storageKey: text("storageKey").notNull(),
  rawToken: varchar("rawToken", { length: 96 }).notNull().unique(),
  accessKey: varchar("accessKey", { length: 96 }),
  accessKeyStatus: mysqlEnum("accessKeyStatus", ["active", "revoked"]).default("active").notNull(),
  accessKeyExpiresAt: timestamp("accessKeyExpiresAt"),
  requestCount: int("requestCount").default(0).notNull(),
  lastUsedAt: timestamp("lastUsedAt"),
  version: int("version").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const luaFileVersions = mysqlTable("lua_file_versions", {
  id: int("id").autoincrement().primaryKey(),
  luaFileId: int("luaFileId").notNull(),
  userId: int("userId").notNull(),
  version: int("version").notNull(),
  code: text("code").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Conversation = typeof conversations.$inferSelect;
export type ChatMessage = typeof chatMessages.$inferSelect;
export type UploadedFile = typeof uploadedFiles.$inferSelect;
export type GeneratedSite = typeof generatedSites.$inferSelect;
export type BotProject = typeof botProjects.$inferSelect;
export type LuaFile = typeof luaFiles.$inferSelect;
export type LuaFileVersion = typeof luaFileVersions.$inferSelect;
