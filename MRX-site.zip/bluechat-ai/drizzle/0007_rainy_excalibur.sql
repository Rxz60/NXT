ALTER TABLE `lua_files` ADD `accessKeyStatus` enum('active','revoked') DEFAULT 'active' NOT NULL;--> statement-breakpoint
ALTER TABLE `lua_files` ADD `accessKeyExpiresAt` timestamp;--> statement-breakpoint
ALTER TABLE `lua_files` ADD `requestCount` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `lua_files` ADD `lastUsedAt` timestamp;