import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function unauthenticatedContext(): TrpcContext {
  return { user: null, req: { protocol: "https", headers: {} } as TrpcContext["req"], res: { clearCookie: () => undefined } as TrpcContext["res"] };
}

describe("MRX protected procedures", () => {
  it("does not expose conversation history to signed-out visitors", async () => {
    const caller = appRouter.createCaller(unauthenticatedContext());
    await expect(caller.conversations.list()).rejects.toThrow("Please login");
  });

  it("protects voice, image, and deletion operations", async () => {
    const caller = appRouter.createCaller(unauthenticatedContext());
    await expect(caller.voice.transcribe({ key: "voice/test.webm", language: "ar" })).rejects.toThrow("Please login");
    await expect(caller.image.generate({ conversationId: 1, prompt: "صورة" })).rejects.toThrow("Please login");
    await expect(caller.conversations.remove({ conversationId: 1 })).rejects.toThrow("Please login");
  });

  it("protects generated sites and bot token operations", async () => {
    const caller = appRouter.createCaller(unauthenticatedContext());
    await expect(caller.sites.list()).rejects.toThrow("Please login");
    await expect(caller.sites.generate({ prompt: "أنشئ موقعاً لمقهى" })).rejects.toThrow("Please login");
    await expect(caller.bots.create({ platform: "telegram", name: "MRX Bot", prompt: "يرد على الأسئلة", token: "1234567890:secret-token" })).rejects.toThrow("Please login");
    await expect(caller.bots.get({ id: 1 })).rejects.toThrow("Please login");
    await expect(caller.bots.remove({ id: 1 })).rejects.toThrow("Please login");
  });

  it("protects site publishing and version editing", async () => {
    const caller = appRouter.createCaller(unauthenticatedContext());
    await expect(caller.sites.publish({ id: 1 })).rejects.toThrow("Please login");
    await expect(caller.sites.unpublish({ id: 1 })).rejects.toThrow("Please login");
    await expect(caller.sites.edit({ id: 1, instruction: "غيّر اللون" })).rejects.toThrow("Please login");
  });

  it("protects Lua vault uploads and updates", async () => {
    const caller = appRouter.createCaller(unauthenticatedContext());
    await expect(caller.lua.list()).rejects.toThrow("Please login");
    await expect(caller.lua.create({ name: "Main", filename: "main.lua", code: "print('MRX')" })).rejects.toThrow("Please login");
    await expect(caller.lua.update({ id: 1, code: "print('updated')" })).rejects.toThrow("Please login");
  });

  it("keeps Lua management behind authentication", async () => {
    const caller = appRouter.createCaller(unauthenticatedContext());
    await expect(caller.lua.get({ id: 1 })).rejects.toThrow("Please login");
    await expect(caller.lua.versions({ id: 1 })).rejects.toThrow("Please login");
    await expect(caller.lua.keyStatus({ id: 1 })).rejects.toThrow("Please login");
    await expect(caller.lua.rotateKey({ id: 1 })).rejects.toThrow("Please login");
    await expect(caller.lua.revokeKey({ id: 1 })).rejects.toThrow("Please login");
  });

  it("returns the current user through the auth contract", async () => {
    const user = { id: 7, openId: "mrx-test-user", name: "MRX Tester", email: "tester@example.com", loginMethod: "oauth", role: "user" as const, createdAt: new Date(), updatedAt: new Date(), lastSignedIn: new Date() };
    const caller = appRouter.createCaller({ ...unauthenticatedContext(), user });
    await expect(caller.auth.me()).resolves.toMatchObject({ id: 7, openId: "mrx-test-user" });
  });
});
