import "dotenv/config";
import express from "express";
import { createServer } from "http";
import net from "net";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";
import { and, eq } from "drizzle-orm";
import { luaFiles } from "../../drizzle/schema";
import { getDb } from "../db";

const rawNotFound = (res: express.Response) => res.status(404).type("text/plain").send("Terabyte error404");

function makeLuaLoader(origin: string, token: string, accessKey: string) {
  const endpoint = `${origin}/api/mrx/lua/${encodeURIComponent(token)}/execute`;
  return `-- MRX protected loader\n-- The Lua source is never returned by this endpoint.\nlocal HttpService = game:GetService("HttpService")\nlocal ENDPOINT = ${JSON.stringify(endpoint)}\nlocal ACCESS_KEY = ${JSON.stringify(accessKey)}\nlocal httpRequest = request or (syn and syn.request) or function(options)\n    local response = HttpService:RequestAsync({ Url = options.Url, Method = options.Method, Headers = options.Headers, Body = options.Body })\n    return { StatusCode = response.StatusCode, Body = response.Body }\nend\nlocal function MRX(action, payload)\n    local response = httpRequest({\n        Url = ENDPOINT,\n        Method = "POST",\n        Headers = { ["Content-Type"] = "application/json", ["X-MRX-Key"] = ACCESS_KEY },\n        Body = HttpService:JSONEncode({ action = action, payload = payload or {} })\n    })\n    if not response or response.StatusCode ~= 200 then return nil, "Terabyte error404" end\n    local ok, data = pcall(function() return HttpService:JSONDecode(response.Body) end)\n    if not ok then return nil, "Invalid MRX response" end\n    return data.result, data.error\nend\nreturn MRX`;
}

function isPortAvailable(port: number): Promise<boolean> {
  return new Promise(resolve => {
    const server = net.createServer();
    server.listen(port, () => {
      server.close(() => resolve(true));
    });
    server.on("error", () => resolve(false));
  });
}

async function findAvailablePort(startPort: number = 3000): Promise<number> {
  for (let port = startPort; port < startPort + 20; port++) {
    if (await isPortAvailable(port)) {
      return port;
    }
  }
  throw new Error(`No available port found starting from ${startPort}`);
}

async function startServer() {
  const app = express();
  const server = createServer(app);
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  registerStorageProxy(app);
  registerOAuthRoutes(app);
  app.get("/raw/lua/:token", async (req, res) => {
    const db = await getDb();
    if (!db) return res.status(503).type("text/plain").send("Raw service unavailable");
    const accessKey = typeof req.query.key === "string" ? req.query.key : "";
    const rows = await db.select({ id: luaFiles.id, code: luaFiles.code, filename: luaFiles.filename, accessKeyStatus: luaFiles.accessKeyStatus, accessKeyExpiresAt: luaFiles.accessKeyExpiresAt }).from(luaFiles).where(and(eq(luaFiles.rawToken, req.params.token), eq(luaFiles.accessKey, accessKey))).limit(1);
    const file = rows[0];
    if (!file || file.accessKeyStatus !== "active" || (file.accessKeyExpiresAt && file.accessKeyExpiresAt.getTime() <= Date.now())) return rawNotFound(res);
    await db.update(luaFiles).set({ requestCount: (await db.select({ requestCount: luaFiles.requestCount }).from(luaFiles).where(eq(luaFiles.id, file.id)).limit(1))[0]?.requestCount + 1 || 1, lastUsedAt: new Date() }).where(eq(luaFiles.id, file.id));
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Cache-Control", "no-store");
    return res.send(makeLuaLoader(`${req.protocol}://${req.get("host")}`, req.params.token, accessKey));
  });
  app.post("/api/mrx/lua/:token/execute", async (req, res) => {
    const db = await getDb();
    if (!db) return res.status(503).json({ error: "Service unavailable" });
    const accessKey = req.get("X-MRX-Key") || "";
    const rows = await db.select({ id: luaFiles.id, accessKeyStatus: luaFiles.accessKeyStatus, accessKeyExpiresAt: luaFiles.accessKeyExpiresAt }).from(luaFiles).where(and(eq(luaFiles.rawToken, req.params.token), eq(luaFiles.accessKey, accessKey))).limit(1);
    const file = rows[0];
    if (!file || file.accessKeyStatus !== "active" || (file.accessKeyExpiresAt && file.accessKeyExpiresAt.getTime() <= Date.now())) return rawNotFound(res);
    const action = typeof req.body?.action === "string" ? req.body.action : "";
    const payload = req.body?.payload && typeof req.body.payload === "object" ? req.body.payload : {};
    const allowedActions: Record<string, (data: Record<string, unknown>) => unknown> = {
      ping: () => ({ ok: true, service: "MRX" }),
      echo: data => ({ value: typeof data.value === "string" ? data.value.slice(0, 2000) : "" }),
    };
    const handler = allowedActions[action];
    if (!handler) return res.status(400).json({ error: "Action not allowed" });
    return res.json({ result: handler(payload) });
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  // development mode uses Vite, production mode uses static files
  if (process.env.NODE_ENV === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  const preferredPort = parseInt(process.env.PORT || "3000");
  const port = await findAvailablePort(preferredPort);

  if (port !== preferredPort) {
    console.log(`Port ${preferredPort} is busy, using port ${port} instead`);
  }

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
